
def helo():
    print("hello")