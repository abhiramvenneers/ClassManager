from django.contrib import admin
from .models import Custom,Topic,Blog

# Register your models here.
admin.site.register(Custom)
admin.site.register(Topic)
admin.site.register(Blog)